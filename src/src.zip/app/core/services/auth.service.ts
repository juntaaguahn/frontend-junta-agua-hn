import { Injectable, signal, computed, inject, Injector } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthResponse, Usuario, UsuarioLogueado } from '../models';
import { OfflineService } from './offline.service';
import { PeriodoService } from './periodo.service';

const httOpciones = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  private injector = inject(Injector);
  private apiUrl = `${environment.apiUrl}/auth`;

  private get offline(): OfflineService {
    return this.injector.get(OfflineService);
  }

  private get periodo(): PeriodoService {
    return this.injector.get(PeriodoService);
  }

  private readonly TOKEN_KEY = 'ja_token';
  private readonly USER_KEY = 'ja_user';

  // Estado reactivo con signals
  private _token = signal<string | null>(localStorage.getItem(this.TOKEN_KEY));
  private _user = signal<UsuarioLogueado | null>(
    JSON.parse(localStorage.getItem(this.USER_KEY) || 'null'),
  );

  readonly token = this._token.asReadonly();
  readonly user = this._user.asReadonly();
  readonly isLoggedIn = computed(() => !!this._token());
  readonly rol = computed(() => this._user()?.rol || null);

  login(username: string, password: string): Observable<AuthResponse> {
    const body = { username, password };
    const apiUrl2 = `${environment.apiUrl}/auth/login`;
    console.log('AuthService login', apiUrl2, body);
    return this.http.post<AuthResponse>(`${apiUrl2}`, body, httOpciones).pipe(
      tap((res) => {
        console.log('Login response', res);
        this.setSession(res);
      }),
    );
  }

  register(data: Partial<Usuario>): Observable<Usuario> {
    return this.http.post<Usuario>(`${this.apiUrl}/register`, data);
  }

  changePassword(actual: string, nueva: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/password`, { actual, nueva });
  }

  me(): Observable<UsuarioLogueado> {
    return this.http.get<UsuarioLogueado>(`${this.apiUrl}/me`).pipe(tap((u) => this._user.set(u)));
  }

  private setSession(res: AuthResponse) {
    localStorage.setItem(this.TOKEN_KEY, res.token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(res.user));
    this._token.set(res.token);
    this._user.set(res.user);
    // Nueva sesión: limpiar réplica offline del usuario anterior
    void this.offline.clearAllData();
    // Cargar período asignado al usuario recién logueado
    this.periodo.cargarDesdeSesion();
  }

  logout() {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    document.cookie.split(';').forEach((c) => {
      document.cookie = c
        .replace(/^ +/, '')
        .replace(/=.*/, `=;expires=${new Date().toUTCString()};path=/`);
    });
    this._token.set(null);
    this._user.set(null);
    void this.offline.clearAllData();
    this.periodo.limpiar();
    this.router.navigate(['/login']);
  }

  hasRole(...roles: string[]): boolean {
    const r = this.rol();
    return !!r && roles.includes(r);
  }
}
