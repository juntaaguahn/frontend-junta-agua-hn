import { Component, inject, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { Message } from 'primeng/message';
import { PasswordModule } from 'primeng/password';
import { SelectModule } from 'primeng/select';
import { UsuariosService } from '../../../core/services/usuarios.service';
import { Rol, Usuario } from '../../../core/models';

@Component({
  selector: 'app-usuario-form',
  standalone: true,
  imports: [
    FormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    Message,
    PasswordModule,
    SelectModule,
  ],
  templateUrl: './usuario-form.html',
  styleUrl: './usuario-form.scss',
})
export class UsuarioForm {
  private service = inject(UsuariosService);

  visible = signal(false);
  editando = signal(false);
  usuarioForm = signal<Partial<Usuario>>({});
  errorPassword = signal('');
  guardando = signal(false);

  guardado = output();

  roles: { label: string; value: Rol }[] = [
    { label: 'Admin', value: 'admin' },
    { label: 'Cajero', value: 'cajero' },
    { label: 'Lecturista', value: 'lecturador' },
  ];

  abrirNuevo() {
    this.usuarioForm.set({
      nombre: '',
      username: '',
      email: '',
      password: '',
      rol: 'lecturador',
      estado: 'activo',
    });
    this.editando.set(false);
    this.errorPassword.set('');
    this.guardando.set(false);
    this.visible.set(true);
  }

  abrirEditar(u: Usuario) {
    this.usuarioForm.set({ ...u, password: '' });
    this.editando.set(true);
    this.errorPassword.set('');
    this.guardando.set(false);
    this.visible.set(true);
  }

  cancelar() {
    this.visible.set(false);
  }

  validarPassword(pw: string): boolean {
    if (!pw && !this.editando()) {
      this.errorPassword.set('La contraseña es requerida');
      return false;
    }
    if (!pw) return true;
    if (pw.length < 8) {
      this.errorPassword.set('Debe tener al menos 8 caracteres');
      return false;
    }
    if (!/[A-Z]/.test(pw)) {
      this.errorPassword.set('Debe contener una letra mayúscula');
      return false;
    }
    if (!/[!@#$%^&*(),.?":{}|<>_\-+=\[\]\\;'/]/.test(pw)) {
      this.errorPassword.set('Debe contener un carácter especial');
      return false;
    }
    this.errorPassword.set('');
    return true;
  }

  guardar(form: any) {
    const data = this.usuarioForm();

    if (!this.validarPassword(data.password || '')) return;

    this.guardando.set(true);
    const obs =
      this.editando() && data.id ? this.service.update(data.id, data) : this.service.create(data);

    obs.subscribe({
      next: () => {
        this.guardando.set(false);
        this.visible.set(false);
        this.guardado.emit();
      },
      error: () => {
        this.guardando.set(false);
      },
    });
  }
}
