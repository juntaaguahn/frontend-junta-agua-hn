export const CURRENCY = 'L';
